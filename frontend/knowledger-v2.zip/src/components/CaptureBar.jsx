import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'react-toastify';
import { AiOutlineArrowRight, AiOutlineUpload, AiOutlineSearch } from 'react-icons/ai';
import { GiBrain } from 'react-icons/gi';
import 'react-toastify/dist/ReactToastify.css';
import Mousetrap from 'mousetrap';
import 'mousetrap-global-bind';

const CaptureBar = () => {
  const [input, setInput] = useState('');
  const [error, setError] = useState(null);
  const [isCaptureMode, setIsCaptureMode] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [theme, setTheme] = useState('system');
  const [dropdownVisible, setDropdownVisible] = useState(false);
  const inputRef = useRef(null);

  // Focus the input field when the hotkey is pressed
  useEffect(() => {
    Mousetrap.bindGlobal('ctrl+space', () => {
      if (inputRef.current) {
        inputRef.current.focus();
        setIsFocused(true);
      }
    });

    Mousetrap.bindGlobal('ctrl+m', () => {
      setIsCaptureMode((prev) => !prev);
      toast.info(isCaptureMode ? 'Switched to Search Mode' : 'Switched to Capture Mode', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
      });
    });

    return () => {
      Mousetrap.unbind('ctrl+space');
      Mousetrap.unbind('ctrl+m');
    };
  }, [isCaptureMode]);

  // Deselect the chatbar when pressing Esc
  useEffect(() => {
    Mousetrap.bindGlobal('esc', () => {
      if (inputRef.current) {
        inputRef.current.blur();
        setIsFocused(false);
      }
    });

    return () => {
      Mousetrap.unbind('esc');
    };
  }, []);

  const handleInputChange = (e) => {
    setInput(e.target.value);
    if (!e.target.value.trim()) {
      setError('Input cannot be empty!');
    } else if (e.target.value.length > 100) {
      setError('Input cannot exceed 100 characters!');
    } else {
      setError(null);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !error && input.trim()) {
      if (isCaptureMode) {
        toast.success('Note captured successfully!', {
          position: 'top-center',
          autoClose: 3000,
          hideProgressBar: true,
        });
      } else {
        toast.info(`Searching for "${input}"...`, {
          position: 'top-center',
          autoClose: 3000,
          hideProgressBar: true,
        });
      }
      setInput('');
    }
  };

  const handleSubmit = () => {
    if (!error && input.trim()) {
      if (isCaptureMode) {
        toast.success('Note captured successfully!', {
          position: 'top-center',
          autoClose: 3000,
          hideProgressBar: true,
        });
      } else {
        toast.info(`Searching for "${input}"...`, {
          position: 'top-center',
          autoClose: 3000,
          hideProgressBar: true,
        });
      }
      setInput('');
    }
  };

  const toggleMode = () => {
    setIsCaptureMode((prev) => !prev);
  };

  const toggleDropdown = () => {
    setShowDropdown((prev) => !prev);
  };

  // Apply the selected theme
  const applyTheme = (selectedTheme) => {
    if (selectedTheme === 'light') {
      document.documentElement.classList.add('light-theme');
      document.documentElement.classList.remove('dark-theme');
    } else if (selectedTheme === 'dark') {
      document.documentElement.classList.add('dark-theme');
      document.documentElement.classList.remove('light-theme');
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) {
        document.documentElement.classList.add('dark-theme');
        document.documentElement.classList.remove('light-theme');
      } else {
        document.documentElement.classList.add('light-theme');
        document.documentElement.classList.remove('dark-theme');
      }
    }
    localStorage.setItem('theme', selectedTheme);
  };

  const handleThemeChange = (selectedTheme) => {
    setTheme(selectedTheme);
    applyTheme(selectedTheme);
  };

  return (
    <div className="capture-container">
      <h1 className="header-text">Hi, what do you want to know?</h1>
      <div className={`capture-bar-wrapper ${isFocused ? 'focused' : ''}`}>
        <button className="mode-switch-btn" onClick={toggleMode}>
          <span className="mode-tooltip">
            {isCaptureMode ? 'Capture Mode - Click to switch to Search Mode' : 'Search Mode - Click to switch to Capture Mode'}
          </span>
          {isCaptureMode ? <GiBrain size={24} /> : <AiOutlineSearch size={24} />}
        </button>
        <input
          type="text"
          className="capture-input"
          placeholder={isCaptureMode ? 'Capture your thoughts...' : 'Search...'}
          value={input}
          onChange={handleInputChange}
          onKeyDown={handleKeyPress}
          ref={inputRef}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />
        <button className="upload-btn" aria-label="Upload">
          <AiOutlineUpload size={24} />
        </button>
        <button className="submit-btn" onClick={handleSubmit} aria-label="Submit">
          <AiOutlineArrowRight size={24} />
        </button>
      </div>
      {error && <p className="error-text">{error}</p>}

      <button className="dropdown-btn" onClick={toggleDropdown}>
        See your Knowledging suggestions <span className={`arrow ${showDropdown ? 'down' : 'right'}`}>›</span>
      </button>

      {showDropdown && (
        <div className="main-grid">
          <div className="info-section resurface-section">
            <h2>Resurface</h2>
            <div className="info-grid">
              <div className="info-item clickable">Item 1</div>
              <div className="info-item clickable">Item 2</div>
              <div className="info-item clickable">Item 3</div>
              <div className="info-item clickable">Item 4</div>
            </div>
          </div>

          <div className="discoveries-section">
            <h2>Discover</h2>
            <div className="info-grid">
              <div className="info-item clickable">Discovery 1</div>
              <div className="info-item clickable">Discovery 2</div>
              <div className="info-item clickable">Discovery 3</div>
              <div className="info-item clickable">Discovery 4</div>
            </div>
          </div>
        </div>
      )}

      {/* Theme Dropdown */}
      <div className="theme-toggle">
        <button onClick={() => setDropdownVisible(!dropdownVisible)}>
          Theme: {theme.charAt(0).toUpperCase() + theme.slice(1)}
        </button>
        {dropdownVisible && (
          <ul className="dropdown-menu">
            <li onClick={() => handleThemeChange('light')}>Light</li>
            <li onClick={() => handleThemeChange('dark')}>Dark</li>
            <li onClick={() => handleThemeChange('system')}>System</li>
          </ul>
        )}
      </div>
    </div>
  );
};

export default CaptureBar;
